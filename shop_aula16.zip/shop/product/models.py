from shop import db
from datetime import datetime

class Brand(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False, unique=True)
 
    def __repr__(self):
        return '<Brand %r>' % self.name

class Category(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False, unique=True)

    def __repr__(self):
        return '<Category %r>' % self.name

class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False, unique=True)
    description = db.Column(db.String(250), nullable=False, unique=True)
    brand_id = db.Column(db.Integer, db.ForeignKey('brand.id'), nullable=False)
    brand = db.relationship('Brand', backref=db.backref('brands', lazy=True))
    category_id = db.Column(db.Integer, db.ForeignKey('category.id'), nullable=False)
    category = db.relationship('Category', backref=db.backref('categories', lazy=True))
    price = db.Column(db.Numeric(10,2), nullable=False, default=0)
    discount = db.Column(db.Numeric(10,2), nullable=False, default=0)
    stock = db.Column(db.Integer, nullable=False, default=0)
    colors = db.Column(db.String(100), nullable=True)
    image = db.Column(db.String(250), nullable=True, default='image.jpg')
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)

    def __repr__(self):
        return '<Product %r>' % self.name

db.create_all()
