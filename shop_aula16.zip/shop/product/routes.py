from flask import redirect, render_template, url_for, flash, request, session, current_app
from .forms import AddProductForm, AddBrandForm, AddCategoryForm, EditBrandForm, EditCategoryForm
from shop import db, app, photos
from .models import Brand, Category, Product
import secrets, os


@app.route('/products')
def products():
    products = Product.query.all()
    if 'email' not in session:
        flash('Você não está logado!', 'is-warning')
        return redirect(url_for('login'))
    
    return render_template('product/index.html', title='Lista de Produtos', products=products)



@app.route('/add_brand', methods=['GET', 'POST'])
def add_brand():
    if 'email' not in session:
        flash('Você não está logado!', 'is-warning')
        return redirect(url_for('login'))

    form = AddBrandForm(request.form)
    if request.method == 'POST':
        brand = Brand(name=form.name.data)
        db.session.add(brand)
        db.session.commit()
        flash('Marca adicionada!', 'is-info')
        return redirect(url_for('add_brand'))

    return render_template('product/add_brand.html', title='Adicionar Marca', form=form)


@app.route('/edit_brand/<int:id>', methods=['GET', 'POST'])
def edit_brand(id):
    if 'email' not in session:
        flash('Você não está logado!', 'is-warning')
        return redirect(url_for('login'))

    brand = Brand.query.get_or_404(id)
    name = request.form.get('name')

    form = EditBrandForm(request.form)
    form.name.data = brand.name
    if request.method == 'POST':
        brand.name = name
        db.session.commit()
        flash('Marca alterada!', 'is-info')
        return redirect(url_for('brands'))

    return render_template('product/edit_brand.html', title='Editar Marca', brand=brand, form=form)



@app.route('/delete_brand/<int:id>', methods=['GET', 'POST'])
def delete_brand(id):
    if 'email' not in session:
        flash('Você não está logado!', 'is-warning')
        return redirect(url_for('login'))

    if request.method == 'GET':
        brand = Brand.query.get_or_404(id)
        db.session.delete(brand)
        db.session.commit()
        flash('Marca excluída!', 'is-danger')
        return redirect(url_for('brands'))

    return redirect(url_for('brands'))



@app.route('/add_category', methods=['GET', 'POST'])
def add_category():
    if 'email' not in session:
        flash('Você não está logado!', 'is-warning')
        return redirect(url_for('login'))
    
    form = AddCategoryForm(request.form)
    if request.method == 'POST':
        category = Category(name=form.name.data)
        db.session.add(category)
        db.session.commit()
        flash('Categoria adicionada!', 'is-info')
        return redirect(url_for('add_category'))

    return render_template('product/add_category.html', title='Adicionar Categoria', form=form)


@app.route('/edit_category/<int:id>', methods=['GET', 'POST'])
def edit_category(id):
    if 'email' not in session:
        flash('Você não está logado!', 'is-warning')
        return redirect(url_for('login'))

    category = Category.query.get_or_404(id)
    name = request.form.get('name')

    form = EditCategoryForm(request.form)
    form.name.data = category.name
    if request.method == 'POST':
        category.name = name
        db.session.commit()
        flash('Categoria alterada!', 'is-info')
        return redirect(url_for('categories'))

    return render_template('product/edit_category.html', title='Editar Categoria', category=category, form=form)



@app.route('/delete_category/<int:id>', methods=['GET', 'POST'])
def delete_category(id):
    if 'email' not in session:
        flash('Você não está logado!', 'is-warning')
        return redirect(url_for('login'))

    if request.method == 'GET':
        category = Category.query.get_or_404(id)
        db.session.delete(category)
        db.session.commit()
        flash('Categoria excluída!', 'is-danger')
        return redirect(url_for('categories'))

    return redirect(url_for('categories'))




@app.route('/add_product', methods=['GET', 'POST'])
def add_product():
    if 'email' not in session:
        flash('Você não está logado!', 'is-warning')
        return redirect(url_for('login'))


    brands = Brand.query.all()
    categories = Category.query.all()
    form = AddProductForm(request.form)
    if request.method == 'POST':
        image = photos.save(request.files.get('image'), name=secrets.token_hex(10)+'.')
        name = form.name.data
        description = form.description.data
        brand_id = request.form.get('brand_id')
        category_id = request.form.get('category_id')
        price = form.price.data
        discount = form.discount.data
        stock = form.stock.data
        colors = form.colors.data
        product = Product(name=name, description=description, brand_id=brand_id, category_id=category_id, price=price, discount=discount, stock=stock, colors=colors, image=image)
        db.session.add(product)
        db.session.commit()
        flash('Produto adicionado!', 'is-info')
        return redirect(url_for('admin'))

    return render_template('product/add_product.html', title='Adicionar Produto', form=form, brands=brands, categories=categories)



@app.route('/edit_product/<int:id>', methods=['GET', 'POST'])
def edit_product(id):
    if 'email' not in session:
        flash('Você não está logado!', 'is-warning')
        return redirect(url_for('login'))

    brands = Brand.query.all()
    categories = Category.query.all()
    product = Product.query.get_or_404(id)
    brand = request.form.get('brand_id')
    category = request.form.get('category_id')
    form = AddProductForm(request.form)

    if request.method == 'POST':
        product.name = form.name.data
        product.description = form.description.data
        product.brand_id = brand
        product.category_id = category
        product.price = form.price.data
        product.discount = form.discount.data
        product.stock = form.stock.data
        product.colors = form.colors.data

        if request.files.get('image'):
            try:
                os.unlink(os.path.join(current_app.root_path, 'static/images/'+product.image))
                product.image = photos.save(request.files.get('image'), name=secrets.token_hex(10)+'.')
            except:
                product.image = photos.save(request.files.get('image'), name=secrets.token_hex(10)+'.')

        db.session.commit()
        flash('Produto alterado!', 'is-info')
        return redirect(url_for('admin'))

    form.name.data = product.name
    form.description.data = product.description
    form.price.data = product.price
    form.discount.data = product.discount
    form.stock.data = product.stock
    form.colors.data = product.colors

    return render_template('product/edit_product.html', title='Editar Produto', form=form, brand=brand, category=category, brands=brands, categories=categories, product=product)


