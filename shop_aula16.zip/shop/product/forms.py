from flask_wtf.file import FileAllowed, FileField, FileRequired
from wtforms import Form, IntegerField, StringField, BooleanField, TextAreaField, SelectField, DecimalField, validators

from .models import Brand, Category

brand_choices = Brand.query.all()
category_choices = Category.query.all()

class AddBrandForm(Form):
    name = StringField('Nome', [validators.DataRequired()])


class EditBrandForm(Form):
    name = StringField('Nome', [validators.DataRequired()])


class AddCategoryForm(Form):
    name = StringField('Nome', [validators.DataRequired()])


class EditCategoryForm(Form):
    name = StringField('Nome', [validators.DataRequired()])


class AddProductForm(Form):
    name = StringField('Nome', [validators.DataRequired()])
    description = TextAreaField('Descrição', [validators.DataRequired()])
    price = DecimalField('Preço', [validators.DataRequired()])
    discount = DecimalField('Desconto', [validators.DataRequired()])
    stock = IntegerField('Estoque', [validators.DataRequired()])
    colors = TextAreaField('Cores', [validators.DataRequired()])
    image = FileField('Imagem', validators=[FileAllowed(['jpg', 'png', 'bmp', 'gip', 'jpeg'])])

print(brand_choices)
