from wtforms import Form, StringField, BooleanField, PasswordField,FileField , validators

class RegisterForm(Form):
    name = StringField('Nome', [validators.DataRequired()])
    username = StringField('Usuário', [validators.DataRequired()])
    email = StringField('Email', [validators.DataRequired()])
    password = PasswordField('Senha', [validators.DataRequired(),
                                validators.EqualTo('confirm', message='Senhas devem ser iguais.')])
    confirm = PasswordField('Confirme a senha', [validators.DataRequired()])
    photo = FileField('Foto')
    

class LoginForm(Form):
    email = StringField('Email', [validators.DataRequired()])
    password = PasswordField('Senha', [validators.DataRequired()])
