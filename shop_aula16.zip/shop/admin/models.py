from shop import db

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), unique=False, nullable=False)
    username = db.Column(db.String(50), unique=False, nullable=False)
    email = db.Column(db.String(200), unique=False, nullable=False)
    password = db.Column(db.String(180), unique=False, nullable=False)
    photo = db.Column(db.String(250), unique=False, nullable=False, default='profile.jpg')


    def __repr__(self):
        return '<User %r>' % self.username

# descomente para criar o banco
db.create_all()
