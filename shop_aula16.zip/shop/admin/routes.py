from flask import render_template, session, request, url_for, redirect, flash

from shop import app, db, bcrypt
from .forms import RegisterForm, LoginForm
from .models import User
import os
from shop.product.models import Product, Brand, Category


@app.route('/')
def home():
    page = request.args.get('page', 1, type=int)
    products = Product.query.filter(Product.stock > 0).paginate(page=page, per_page=2)
    categories = Category.query.join(Product, (Category.id == Product.category_id)).all()
    brands = Brand.query.join(Product, (Brand.id == Product.brand_id)).all()
    
    return render_template('admin/index.html', title='Shop - Produtos', products=products, categories=categories, brands=brands)


@app.route('/filter_brand/<int:id>')
def filter_brand(id):
    brand = Product.query.filter_by(brand_id=id)
    categories = Category.query.join(Product, (Category.id == Product.category_id)).all()

    brands = Brand.query.join(Product, (Brand.id == Product.brand_id)).all()
    
    return render_template('admin/index.html', brand=brand, brands=brands, categories=categories)


@app.route('/filter_category/<int:id>')
def filter_category(id):
    category = Product.query.filter_by(category_id=id)
    brands = Brand.query.join(Product, (Brand.id == Product.brand_id)).all()
    categories = Category.query.join(Product, (Category.id == Product.category_id)).all()
    
    return render_template('admin/index.html', category=category, categories=categories, brands=brands)


@app.route('/admin')
def admin():
    products = Product.query.all()
    if 'email' not in session:
        flash('Você não está logado!', 'is-warning')
        return redirect(url_for('login'))
    return render_template('product/index.html', title='Página do administrador', products=products)


@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegisterForm(request.form)
    if request.method == 'POST' and form.validate():
        hash_password = bcrypt.generate_password_hash(form.password.data)
        user = User(name=form.name.data, username=form.username.data, email=form.email.data, password=hash_password)
        db.session.add(user)
        db.session.commit()
        flash('Obrigado por se registrar!', 'is-info')
        return redirect(url_for('login'))
    return render_template('admin/register.html', title='Registro de usuário', form=form)


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm(request.form)
    if request.method == 'POST' and form.validate():
        user = User.query.filter_by(email=form.email.data).first()
        if user and bcrypt.check_password_hash(user.password, form.password.data):
            session['email'] = form.email.data
            flash('Você está logado!', 'is-info')
            return redirect(request.args.get('next') or url_for('admin'))
        else:
            flash('Senha ou usuário inválidos!', 'is-warning')

    return render_template('admin/login.html', title='Página de Login', form=form)


@app.route('/brands')
def brands():
    brands = Brand.query.all()
    if 'email' not in session:
        flash('Você não está logado!', 'is-warning')
        return redirect(url_for('login'))
    return render_template('admin/brands.html', title='Marcas', brands=brands)


@app.route('/categories')
def categories():
    categories = Category.query.all()
    if 'email' not in session:
        flash('Você não está logado!', 'is-warning')
        return redirect(url_for('login'))
    return render_template('admin/categories.html', title='Categorias', categories=categories)


